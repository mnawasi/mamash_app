import 'package:flutter/material.dart';

class ScanPage extends StatelessWidget {
  const ScanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Scan"),
        backgroundColor: Colors.green,
      ),
      body: const Center(
        child: Text(
          "QR Scanner Coming Soon",
          style: TextStyle(fontSize: 22),
        ),
      ),
    );
  }
}