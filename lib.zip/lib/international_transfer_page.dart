import 'package:flutter/material.dart';

class InternationalTransferPage extends StatelessWidget {
  const InternationalTransferPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("International Transfer"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          "International Transfers\n(Coming Soon)",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}