import 'package:flutter/material.dart';

class TvSubscriptionPage extends StatefulWidget {
  const TvSubscriptionPage({super.key});

  @override
  State<TvSubscriptionPage> createState() => _TvSubscriptionPageState();
}

class _TvSubscriptionPageState extends State<TvSubscriptionPage> {
  final TextEditingController smartCardController =
      TextEditingController();

  String? selectedProvider;
  String? selectedBouquet;

  final List<String> providers = [
    "DStv",
    "GOtv",
    "Startimes",
  ];

  final List<String> bouquets = [
    "Basic",
    "Compact",
    "Compact Plus",
    "Premium",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("TV Subscription"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                child: const Column(
                  children: [
                    Text(
                      "Wallet Balance",
                      style: TextStyle(color: Colors.grey),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "₦0.00",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "TV Provider",
                border: OutlineInputBorder(),
              ),
              items: providers.map((provider) {
                return DropdownMenuItem(
                  value: provider,
                  child: Text(provider),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedProvider = value;
                });
              },
            ),

            const SizedBox(height: 20),

            TextField(
              controller: smartCardController,
              decoration: const InputDecoration(
                labelText: "Smart Card / IUC Number",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Select Bouquet",
                border: OutlineInputBorder(),
              ),
              items: bouquets.map((bouquet) {
                return DropdownMenuItem(
                  value: bouquet,
                  child: Text(bouquet),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedBouquet = value;
                });
              },
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () {
                  if (selectedProvider == null ||
                      selectedBouquet == null ||
                      smartCardController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Please complete all fields"),
                      ),
                    );
                    return;
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("TV subscription coming soon..."),
                    ),
                  );
                },
                child: const Text(
                  "PAY TV SUBSCRIPTION",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}