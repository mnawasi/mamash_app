import 'package:flutter/material.dart';

class ElectricityPage extends StatefulWidget {
  const ElectricityPage({super.key});

  @override
  State<ElectricityPage> createState() => _ElectricityPageState();
}

class _ElectricityPageState extends State<ElectricityPage> {
  final TextEditingController meterController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  String? selectedDisco;
  String? selectedMeterType;

  final List<String> discos = [
    "IKEDC",
    "EKEDC",
    "AEDC",
    "IBEDC",
    "KEDCO",
    "PHED",
    "EEDC",
    "BEDC",
    "KAEDCO",
    "JED",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Electricity"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                child: const Column(
                  children: [
                    Text(
                      "Wallet Balance",
                      style: TextStyle(color: Colors.grey),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "₦0.00",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Distribution Company",
                border: OutlineInputBorder(),
              ),
              items: discos.map((disco) {
                return DropdownMenuItem(
                  value: disco,
                  child: Text(disco),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedDisco = value;
                });
              },
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Meter Type",
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(
                  value: "Prepaid",
                  child: Text("Prepaid"),
                ),
                DropdownMenuItem(
                  value: "Postpaid",
                  child: Text("Postpaid"),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  selectedMeterType = value;
                });
              },
            ),

            const SizedBox(height: 20),

            TextField(
              controller: meterController,
              decoration: const InputDecoration(
                labelText: "Meter Number",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Amount",
                prefixText: "₦",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () {
                  if (selectedDisco == null ||
                      selectedMeterType == null ||
                      meterController.text.isEmpty ||
                      amountController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Please complete all fields"),
                      ),
                    );
                    return;
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Electricity payment coming soon..."),
                    ),
                  );
                },
                child: const Text(
                  "PAY ELECTRICITY BILL",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}