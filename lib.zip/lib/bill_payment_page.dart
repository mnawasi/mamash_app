import 'package:flutter/material.dart';

class BillPaymentPage extends StatelessWidget {
  const BillPaymentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bill Payment"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          "Pay Electricity, TV & Other Bills\n(Coming Soon)",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}