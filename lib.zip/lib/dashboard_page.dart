import 'package:flutter/material.dart';

import 'send_money_page.dart';
import 'receive_money_page.dart';
import 'airtime_page.dart';
import 'buy_data_page.dart';
import 'bill_payment_page.dart';
import 'betting_page.dart';
import 'survey_page.dart';
import 'international_transfer_page.dart';
import 'ai/ai_assistant_page.dart';
import 'transaction_history_page.dart';
import 'notification_page.dart';
import 'profile_page.dart';
import 'wallet_page.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        backgroundColor: Colors.blue,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Mamash",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.notifications,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const NotificationPage(),
                ),
              );
            },
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    const Text(
                      "Wallet Balance",
                      style: TextStyle(
                        color: Colors.white70,
                      ),
                    ),

                    const SizedBox(height: 10),

                    const Text(
                      "₦0.00",
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),

                    const SizedBox(height: 10),

                    ElevatedButton(
                      onPressed: () {},
                      child: const Text("Add Money"),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              const Text(
                "Quick Services",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [

                  serviceTile(
                    context,
                    Icons.send,
                    "Send",
                    SendMoneyPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.call_received,
                    "Receive",
                    ReceiveMoneyPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.phone_android,
                    "Airtime",
                    AirtimePage(),
                  ),

                  serviceTile(
                    context,
                    Icons.wifi,
                    "Data",
                   const BuyDataPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.lightbulb,
                    "Bills",
                    BillPaymentPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.sports_esports,
                    "Betting",
                    BettingPage(),
                  ),
                  serviceTile(
                    context,
                    Icons.assignment,
                    "Survey",
                    SurveyPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.public,
                    "Transfer",
                    InternationalTransferPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.smart_toy,
                    "Mamash AI",
                    AIAssistantPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.history,
                    "History",
                    TransactionHistoryPage(),
                  ),

                  serviceTile(
                    context,
                    Icons.person,
                    "Profile",
                    ProfilePage(),
                  ),

                  serviceTile(
                    context,
                    Icons.account_balance_wallet,
                    "Wallet",
                    const WalletPage(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget serviceTile(
    BuildContext context,
    IconData icon,
    String title,
    Widget page,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(15),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => page,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              blurRadius: 5,
              color: Colors.black12,
              offset: Offset(1, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundColor: Colors.blue.shade100,
              radius: 24,
              child: Icon(
                icon,
                color: Colors.blue,
                size: 28,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}