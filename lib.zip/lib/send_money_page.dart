import 'package:flutter/material.dart';

class SendMoneyPage extends StatelessWidget {
  const SendMoneyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Send Money"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          "Send Money Page",
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}