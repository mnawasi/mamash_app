import 'package:flutter/material.dart';

class BettingPage extends StatelessWidget {
  const BettingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Betting"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          "Betting Wallet Funding\n(Coming Soon)",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}