import 'package:flutter/material.dart';

class BuyDataPage extends StatefulWidget {
  const BuyDataPage({super.key});

  @override
  State<BuyDataPage> createState() => _BuyDataPageState();
}

class _BuyDataPageState extends State<BuyDataPage> {
  final TextEditingController phoneController = TextEditingController();

  String? selectedNetwork;
  String? selectedPlan;

  final List<String> networks = [
    "MTN",
    "Airtel",
    "Glo",
    "9mobile",
  ];

  final List<String> plans = [
    "500MB - ₦150",
    "1GB - ₦300",
    "2GB - ₦600",
    "5GB - ₦1500",
    "10GB - ₦3000",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Buy Data"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                child: const Column(
                  children: [
                    Text(
                      "Wallet Balance",
                      style: TextStyle(color: Colors.grey),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "₦0.00",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Select Network",
                border: OutlineInputBorder(),
              ),
              items: networks.map((network) {
                return DropdownMenuItem(
                  value: network,
                  child: Text(network),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedNetwork = value;
                });
              },
            ),

            const SizedBox(height: 20),

            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: "Phone Number",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Select Data Plan",
                border: OutlineInputBorder(),
              ),
              items: plans.map((plan) {
                return DropdownMenuItem(
                  value: plan,
                  child: Text(plan),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedPlan = value;
                });
              },
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () {
                  if (selectedNetwork == null ||
                      selectedPlan == null ||
                      phoneController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Please complete all fields"),
                      ),
                    );
                    return;
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Data purchase coming soon..."),
                    ),
                  );
                },
                child: const Text(
                  "BUY DATA",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}