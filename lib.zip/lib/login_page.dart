import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'signup_page.dart';
import 'face_verification_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final FirebaseAuth _auth = FirebaseAuth.instance;

  final TextEditingController emailController =
      TextEditingController();

  final TextEditingController passwordController =
      TextEditingController();

  bool obscurePassword = true;
  bool isLoading = false;
  bool rememberMe = false;

  Future<void> loginUser() async {

    if (emailController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please fill all fields"),
        ),
      );

      return;
    }

    try {

      setState(() {
        isLoading = true;
      });

      await _auth.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const FaceVerificationPage(),
        ),
      );

    } on FirebaseAuthException catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            e.message ?? "Login failed",
          ),
        ),
      );

    } finally {

      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }

    }

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0D47A1),
              Color(0xFF1976D2),
              Color(0xFF42A5F5),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 20,
              ),
              child: Container(
                padding: const EdgeInsets.all(25),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  children: [

                    const CircleAvatar(
                      radius: 48,
                      backgroundColor: Color(0xFF1565C0),
                      child: Icon(
                        Icons.account_balance_wallet_rounded,
                        color: Colors.white,
                        size: 55,
                      ),
                    ),

                    const SizedBox(height: 25),

                    const Text(
                      "Welcome Back",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 10),

                    const Text(
                      "Login to continue using Mamash",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(height: 35),
                    TextField(
  controller: emailController,
  keyboardType: TextInputType.emailAddress,
  decoration: InputDecoration(
    labelText: "Email Address",
    hintText: "Enter your email",
    prefixIcon: const Icon(
      Icons.email_outlined,
      color: Color(0xFF1565C0),
    ),
    filled: true,
    fillColor: Colors.grey.shade100,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: BorderSide.none,
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: const BorderSide(
        color: Color(0xFF1565C0),
        width: 2,
      ),
    ),
  ),
),

const SizedBox(height: 20),

TextField(
  controller: passwordController,
  obscureText: obscurePassword,
  decoration: InputDecoration(
    labelText: "Password",
    hintText: "Enter your password",
    prefixIcon: const Icon(
      Icons.lock_outline,
      color: Color(0xFF1565C0),
    ),
    suffixIcon: IconButton(
      icon: Icon(
        obscurePassword
            ? Icons.visibility
            : Icons.visibility_off,
      ),
      onPressed: () {
        setState(() {
          obscurePassword = !obscurePassword;
        });
      },
    ),
    filled: true,
    fillColor: Colors.grey.shade100,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: BorderSide.none,
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: const BorderSide(
        color: Color(0xFF1565C0),
        width: 2,
      ),
    ),
  ),
),

const SizedBox(height: 15),

Row(
  children: [

    Checkbox(
      value: rememberMe,
      activeColor: const Color(0xFF1565C0),
      onChanged: (value) {
        setState(() {
          rememberMe = value!;
        });
      },
    ),

    const Text("Remember Me"),

    const Spacer(),

    TextButton(
      onPressed: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              "Forgot Password coming soon.",
            ),
          ),
        );
      },
      child: const Text(
        "Forgot Password?",
      ),
    ),

  ],
),

const SizedBox(height: 10),

SizedBox(
  width: double.infinity,
  height: 55,
  child: ElevatedButton(
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF1565C0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
    ),
    onPressed: isLoading ? null : loginUser,
    child: isLoading
        ? const CircularProgressIndicator(
            color: Colors.white,
          )
        : const Text(
            "LOGIN",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
  ),
),

const SizedBox(height: 25),
const Text(
  "OR",
  style: TextStyle(
    color: Colors.grey,
    fontWeight: FontWeight.bold,
  ),
),

const SizedBox(height: 20),

SizedBox(
  width: double.infinity,
  height: 55,
  child: OutlinedButton.icon(
    style: OutlinedButton.styleFrom(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
    ),
    onPressed: () {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Phone login coming soon.",
          ),
        ),
      );
    },
    icon: const Icon(
      Icons.phone_android,
      color: Color(0xFF1565C0),
    ),
    label: const Text(
      "Login with Phone Number",
      style: TextStyle(
        color: Colors.black87,
        fontWeight: FontWeight.bold,
      ),
    ),
  ),
),

const SizedBox(height: 15),

SizedBox(
  width: double.infinity,
  height: 55,
  child: OutlinedButton.icon(
    style: OutlinedButton.styleFrom(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
    ),
    onPressed: () {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Google Sign-In will be added soon.",
          ),
        ),
      );
    },
    icon: const Icon(
      Icons.g_mobiledata,
      color: Colors.red,
      size: 32,
    ),
    label: const Text(
      "Continue with Google",
      style: TextStyle(
        color: Colors.black87,
        fontWeight: FontWeight.bold,
      ),
    ),
  ),
),

const SizedBox(height: 25),

Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [

    const Text(
      "Don't have an account?",
    ),

    TextButton(
      onPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => const SignupPage(),
          ),
        );
      },
      child: const Text(
        "Sign Up",
        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
    ),

  ],
),

const SizedBox(height: 25),

const Text(
  "Mamash v1.0.0",
  style: TextStyle(
    color: Colors.grey,
    fontSize: 12,
  ),
),

                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}