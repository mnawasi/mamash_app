import 'package:flutter/material.dart';

class ReceiveMoneyPage extends StatelessWidget {
  const ReceiveMoneyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Receive Money"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          "Receive Money Page",
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}