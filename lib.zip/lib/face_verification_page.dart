import 'package:flutter/material.dart';
import 'dashboard_page.dart';

class FaceVerificationPage extends StatefulWidget {
  const FaceVerificationPage({super.key});

  @override
  State<FaceVerificationPage> createState() =>
      _FaceVerificationPageState();
}

class _FaceVerificationPageState
    extends State<FaceVerificationPage> {
  bool verifying = false;

  Future<void> verifyFace() async {
    setState(() {
      verifying = true;
    });

    // Simulate verification
    await Future.delayed(const Duration(seconds: 3));

    if (!mounted) return;

    setState(() {
      verifying = false;
    });

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const DashboardPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        centerTitle: true,
        title: const Text("Face Verification"),
      ),

      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(25),

          child: Column(
            mainAxisAlignment:
                MainAxisAlignment.center,

            children: [

              const CircleAvatar(
                radius: 70,
                backgroundColor: Colors.blue,

                child: Icon(
                  Icons.face,
                  size: 80,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 30),

              const Text(
                "Verify Your Face",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              const Text(
                "For your security, Mamash requires facial verification before accessing your account.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 40),

              SizedBox(
                width: double.infinity,
                height: 55,

                child: ElevatedButton(
                  onPressed:
                      verifying ? null : verifyFace,

                  child: verifying
                      ? const CircularProgressIndicator(
                          color: Colors.white,
                        )
                      : const Text(
                          "VERIFY FACE",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}