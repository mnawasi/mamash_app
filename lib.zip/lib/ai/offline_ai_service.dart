class OfflineAIService {
  static String getResponse(String message) {
    final text = message.toLowerCase().trim();

    // Greetings
    if (text.contains("hello") ||
        text.contains("hi") ||
        text.contains("hey")) {
      return "Hello 👋 Welcome to Mamash! How can I help you today?";
    }

    // Wallet
    if (text.contains("wallet") ||
        text.contains("add money") ||
        text.contains("deposit")) {
      return "To fund your wallet, open the Add Money page and choose Bank Transfer, Card, or USSD.";
    }

    // Registration
    if (text.contains("register") ||
        text.contains("signup") ||
        text.contains("account")) {
      return "Create your Mamash account using your email, phone number, and password, then verify your email.";
    }

    // KYC
    if (text.contains("kyc") ||
        text.contains("verification")) {
      return "Complete face verification and upload the required details to unlock all wallet features.";
    }

    // Survey
    if (text.contains("survey")) {
      return "Survey Rewards allow you to earn money by completing surveys from our partners.";
    }

    // Transfer
    if (text.contains("transfer")) {
      return "You can transfer money to other users or bank accounts after wallet funding is enabled.";
    }

    // Airtime
    if (text.contains("airtime")) {
      return "Open the Airtime page, enter the phone number, select the network, and complete payment.";
    }

    // Data
    if (text.contains("data")) {
      return "You can buy mobile data for all supported networks inside Mamash.";
    }

    // AI
    if (text.contains("ai")) {
      return "I'm Mamash AI. Soon I'll be upgraded with Google's Gemini AI for smarter conversations.";
    }

    // Default
    return "Sorry, I don't understand that yet. Once Gemini AI is connected, I'll be able to answer many more questions.";
  }
}