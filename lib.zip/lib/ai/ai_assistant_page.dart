import 'package:flutter/material.dart';

class AIAssistantPage extends StatelessWidget {
  const AIAssistantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mamash AI"),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}